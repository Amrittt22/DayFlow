import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { io, Socket } from "socket.io-client";
import { BellRing, ImagePlus, Loader2, MessageCircleMore, Paperclip, Send, SmilePlus, Sparkles, UsersRound, Wifi, WifiOff } from "lucide-react";
import { ChangeEvent, FormEvent, useEffect, useRef, useState } from "react";
import { toast } from "sonner";

const emojiSet = ["👍", "🎉", "❤️", "👏", "🔥", "👀"];
const reactionSet = ["👍", "❤️", "🎉", "👏"];
const timeLabel = (date: Date) => new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(date);

function MemberAvatar({ name, avatarUrl, size = "md" }: { name?: string | null; avatarUrl?: string | null; size?: "sm" | "md" }) {
  return <span className={`pulse-avatar pulse-avatar--${size}`}>{avatarUrl ? <img src={avatarUrl} alt="" /> : (name?.trim().slice(0, 1).toUpperCase() || "D")}</span>;
}

export default function TeamPulse() {
  const { user, isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const messages = trpc.hr.teamMessages.useQuery(undefined, { enabled: isAuthenticated });
  const profile = trpc.hr.myProfile.useQuery(undefined, { enabled: isAuthenticated });
  const [draft, setDraft] = useState("");
  const [socketState, setSocketState] = useState<"connecting" | "live" | "offline">("connecting");
  const [isEmojiOpen, setEmojiOpen] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isAuthenticated) return;
    const socket: Socket = io({ path: "/api/realtime", transports: ["websocket"], withCredentials: true });
    socket.on("connect", () => setSocketState("live"));
    socket.on("connect_error", () => setSocketState("offline"));
    socket.on("team:refresh", () => { utils.hr.teamMessages.invalidate(); });
    return () => {
      socket.disconnect();
    };
  }, [isAuthenticated, utils.hr.teamMessages]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages.data?.messages.length]);

  const sendMessage = trpc.hr.sendTeamMessage.useMutation({ onSuccess: () => { setDraft(""); setEmojiOpen(false); utils.hr.teamMessages.invalidate(); }, onError: error => toast.error(error.message) });
  const toggleReaction = trpc.hr.toggleTeamReaction.useMutation({ onSuccess: () => utils.hr.teamMessages.invalidate(), onError: error => toast.error(error.message) });
  const uploadPhoto = trpc.hr.uploadProfilePhoto.useMutation({ onSuccess: () => { utils.hr.myProfile.invalidate(); utils.hr.teamMessages.invalidate(); toast.success("Profile photo updated"); }, onError: error => toast.error(error.message) });
  const submit = (event: FormEvent) => { event.preventDefault(); if (!draft.trim()) return; sendMessage.mutate({ body: draft }); };
  const choosePhoto = (event: ChangeEvent<HTMLInputElement>) => { const file = event.target.files?.[0]; if (!file) return; if (!(["image/jpeg", "image/png", "image/webp"] as string[]).includes(file.type) || file.size > 4 * 1024 * 1024) { toast.error("Choose a JPEG, PNG, or WebP under 4 MB."); event.target.value = ""; return; } const reader = new FileReader(); reader.onload = () => uploadPhoto.mutate({ dataUrl: String(reader.result), mimeType: file.type as "image/jpeg" | "image/png" | "image/webp" }); reader.readAsDataURL(file); };
  const channel = messages.data?.channel;

  if (messages.isError || profile.isError) {
    return <DashboardLayout><div className="team-pulse mx-auto max-w-6xl pb-12 pt-2"><article className="team-pulse-error"><BellRing className="h-6 w-6 text-[#ff6b55]" /><div><p className="eyebrow">Connection needs a moment</p><h1 className="mt-2 font-[DM_Serif_Display] text-3xl tracking-[-0.04em]">Team Pulse could not load safely.</h1><p className="mt-2 max-w-lg text-sm leading-6 text-[#65717d]">Your messages remain protected. Try again to reconnect your profile and team conversation.</p><Button onClick={() => { messages.refetch(); profile.refetch(); }} className="team-send-button mt-5 rounded-full px-5 text-xs">Reconnect Team Pulse</Button></div></article></div></DashboardLayout>;
  }

  return <DashboardLayout><div className="team-pulse mx-auto max-w-6xl pb-12 pt-2"><header className="team-pulse__header"><div><p className="eyebrow">Team connection</p><h1 className="mt-2 font-[DM_Serif_Display] text-4xl tracking-[-0.045em]">A shared pulse for the day.</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-[#65717d]">Quick updates, warm reactions, and the context your teammates need—without a second workspace.</p></div><div className={`team-pulse__status team-pulse__status--${socketState}`}><span>{socketState === "live" ? <Wifi className="h-4 w-4" /> : socketState === "offline" ? <WifiOff className="h-4 w-4" /> : <Loader2 className="h-4 w-4 animate-spin" />}</span><div><p>{socketState === "live" ? "Live now" : socketState === "offline" ? "Reconnecting" : "Connecting"}</p><small>{socketState === "live" ? "Instant team updates" : "Team history remains available"}</small></div></div></header>
    <div className="team-pulse__grid mt-6"><aside className="team-profile-card"><div className="team-profile-card__orb" /><div className="relative z-10 flex items-start justify-between gap-3"><div><p className="eyebrow">Your signal</p><h2 className="mt-2 font-[DM_Serif_Display] text-3xl tracking-[-0.04em]">Show up as you.</h2></div><Sparkles className="h-5 w-5 text-[#b7f46a]" /></div><div className="relative z-10 mt-7 flex items-center gap-3"><MemberAvatar name={profile.data?.fullName ?? user?.name} avatarUrl={profile.data?.avatarUrl} size="md" /><div><p className="text-sm font-extrabold text-white">{profile.data?.fullName ?? user?.name ?? "Dayflow teammate"}</p><p className="mt-1 text-xs text-[#aebddb]">{profile.data?.department || "Your profile"}</p></div></div><label className="team-photo-button relative z-10 mt-6"><ImagePlus className="h-4 w-4" />{uploadPhoto.isPending ? "Uploading…" : "Add profile photo"}<input type="file" accept="image/jpeg,image/png,image/webp" onChange={choosePhoto} className="sr-only" /></label><p className="relative z-10 mt-3 text-[11px] leading-5 text-[#aebddb]">JPEG, PNG, or WebP up to 4 MB. Your photo appears in the team conversation and directory.</p><div className="team-orbit-graphic" aria-hidden="true"><i /><b /><span /></div></aside>
      <section className="team-chat-card"><div className="team-chat-card__top"><div className="flex items-center gap-3"><span className="team-channel-icon"><MessageCircleMore className="h-4 w-4" /></span><div><p className="text-sm font-extrabold text-[#0b1b40]">{channel?.name ?? "Team pulse"}</p><p className="mt-0.5 text-xs text-[#71819d]">{channel?.description ?? "A shared place for everyday updates."}</p></div></div><div className="flex items-center gap-1.5 text-xs font-bold text-[#477f23]"><i className="team-live-dot" />{socketState === "live" ? "Live" : "History"}</div></div><div className="team-message-list">{messages.isLoading ? <div className="grid min-h-80 place-items-center"><Loader2 className="h-7 w-7 animate-spin text-[#315cff]" /></div> : messages.data?.messages.length ? messages.data.messages.map(message => { const mine = message.senderUserId === user?.id; return <article key={message.id} className={`team-message ${mine ? "team-message--mine" : ""}`}><MemberAvatar name={message.senderName} avatarUrl={message.senderAvatarUrl} size="sm" /><div className="min-w-0"><div className="flex items-center gap-2"><strong>{mine ? "You" : message.senderName || "Teammate"}</strong><span>{timeLabel(message.createdAt)}</span>{message.senderRole === "admin" && <i className="team-role-badge">HR</i>}</div><p>{message.body}</p><div className="team-reactions">{Object.entries(message.reactions).map(([emoji, reaction]) => <button key={emoji} onClick={() => toggleReaction.mutate({ messageId: message.id, emoji })} className={reaction.reacted ? "team-reaction team-reaction--active" : "team-reaction"}>{emoji} <b>{reaction.count}</b></button>)}<div className="team-reaction-picker">{reactionSet.map(emoji => <button key={emoji} onClick={() => toggleReaction.mutate({ messageId: message.id, emoji })}>{emoji}</button>)}</div></div></div></article>; }) : <div className="team-empty"><MessageCircleMore className="h-8 w-8 text-[#315cff]" /><div><p className="eyebrow">Clear the next hand-off</p><h3 className="mt-2 font-[DM_Serif_Display] text-3xl tracking-[-0.04em]">No team update is waiting.</h3><p className="mt-2 text-sm text-[#65717d]">Share the update your team needs before the workday moves on.</p></div></div>}<div ref={endRef} /></div><form onSubmit={submit} className="team-composer"><div className="relative"><textarea value={draft} onChange={event => setDraft(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); submit(event); } }} maxLength={1500} placeholder="Share a team update…" className="team-composer__input" /><button type="button" onClick={() => setEmojiOpen(open => !open)} className="team-composer__emoji" aria-label="Choose emoji"><SmilePlus className="h-5 w-5" /></button>{isEmojiOpen && <div className="team-emoji-menu">{emojiSet.map(emoji => <button key={emoji} type="button" onClick={() => setDraft(value => `${value}${emoji}`)}>{emoji}</button>)}</div>}</div><div className="mt-3 flex items-center justify-between gap-3"><span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-[#7585a1]"><Paperclip className="h-3.5 w-3.5" />Team-only conversation</span><Button disabled={sendMessage.isPending || !draft.trim()} className="team-send-button rounded-full px-5 text-xs"><Send className="h-3.5 w-3.5" />{sendMessage.isPending ? "Sending…" : "Send"}</Button></div></form></section></div></div></DashboardLayout>;
}
