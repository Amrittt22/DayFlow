import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { actionCompleteInput, actionCreateInput } from "./hrSchemas";
import { canCompleteAssignedAction, completeActionItem, createActionItem, getDb, isEligibleActionAssignee, listAdminActionItems, listMyActionItems } from "./db";
import { actionItems, employeeProfiles, users } from "../drizzle/schema";
import { inArray } from "drizzle-orm";

function createContext(user: TrpcContext["user"]): TrpcContext {
  return { user, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("Dayflow Action Center contracts", () => {
  it("requires a signed-in user to read or complete private actions", async () => {
    const caller = appRouter.createCaller(createContext(null));
    await expect(caller.hr.myActions()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.hr.completeAction({ actionId: 1 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("validates bounded Action Center assignment inputs", () => {
    expect(actionCreateInput.parse({ assigneeUserId: 8, title: "Review your updated profile", priority: "high" })).toMatchObject({ assigneeUserId: 8, priority: "high" });
    expect(actionCompleteInput.parse({ actionId: 4 }).actionId).toBe(4);
    expect(() => actionCreateInput.parse({ assigneeUserId: 0, title: "" })).toThrow();
  });

  it("blocks employee accounts from creating actions for other teammates", async () => {
    const caller = appRouter.createCaller(createContext({ id: 77, openId: "employee-action", name: "Employee", email: "employee@example.com", loginMethod: "manus", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }));
    await expect(caller.hr.createAction({ assigneeUserId: 78, title: "Complete profile" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.hr.adminActions()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("requires an active employee profile and limits completion to the assigned user", () => {
    expect(isEligibleActionAssignee(undefined)).toBe(false);
    expect(isEligibleActionAssignee({ active: false })).toBe(false);
    expect(isEligibleActionAssignee({ active: true })).toBe(true);
    expect(canCompleteAssignedAction({ assigneeUserId: 42 }, 42)).toBe(true);
    expect(canCompleteAssignedAction({ assigneeUserId: 42 }, 43)).toBe(false);
    expect(canCompleteAssignedAction(undefined, 42)).toBe(false);
  });

  it("enforces active profile eligibility and returns action data only to the assigned employee", async () => {
    const db = await getDb();
    if (!db) throw new Error("Database is required for Action Center integration coverage.");
    const suffix = `${Date.now().toString(36).slice(-6)}${Math.random().toString(36).slice(2, 7)}`;
    const openIds = [`action-admin-${suffix}`, `action-active-${suffix}`, `action-other-${suffix}`, `action-inactive-${suffix}`, `action-missing-${suffix}`];
    await db.insert(users).values([
      { openId: openIds[0], name: "Action Admin", role: "admin" },
      { openId: openIds[1], name: "Action Assignee", role: "user" },
      { openId: openIds[2], name: "Action Other", role: "user" },
      { openId: openIds[3], name: "Action Inactive", role: "user" },
      { openId: openIds[4], name: "Action Missing", role: "user" },
    ]);
    const seeded = await db.select().from(users).where(inArray(users.openId, openIds));
    const byOpenId = new Map(seeded.map(user => [user.openId, user]));
    const admin = byOpenId.get(openIds[0])!;
    const active = byOpenId.get(openIds[1])!;
    const other = byOpenId.get(openIds[2])!;
    const inactive = byOpenId.get(openIds[3])!;
    try {
      await db.insert(employeeProfiles).values([
        { userId: active.id, employeeCode: `ACT-A-${suffix}`, fullName: "Action Assignee", active: true },
        { userId: other.id, employeeCode: `ACT-O-${suffix}`, fullName: "Action Other", active: true },
        { userId: inactive.id, employeeCode: `ACT-I-${suffix}`, fullName: "Action Inactive", active: false },
      ]);
      await expect(createActionItem(admin.id, { assigneeUserId: inactive.id, title: "Inactive account" })).rejects.toThrow("active Dayflow teammate");
      await expect(createActionItem(admin.id, { assigneeUserId: byOpenId.get(openIds[4])!.id, title: "Missing profile" })).rejects.toThrow("active Dayflow teammate");
      await expect(createActionItem(admin.id, { assigneeUserId: active.id, title: "Scoped completion" })).resolves.toEqual({ success: true });
      const mine = await listMyActionItems(active);
      const someoneElse = await listMyActionItems(other);
      expect(mine.some(action => action.title === "Scoped completion")).toBe(true);
      expect(someoneElse.some(action => action.title === "Scoped completion")).toBe(false);
      const action = mine.find(item => item.title === "Scoped completion")!;
      await expect(completeActionItem(other, { actionId: action.id })).rejects.toThrow("not available to your account");
      await expect(completeActionItem(active, { actionId: action.id })).resolves.toEqual({ success: true });
      const adminQueue = await listAdminActionItems();
      expect(adminQueue.some(item => item.id === action.id && item.assigneeUserId === active.id && item.status === "completed")).toBe(true);
    } finally {
      await db.delete(users).where(inArray(users.openId, openIds));
    }
  });
});
