import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { messageReactionInput, profilePhotoInput, teamMessageInput } from "./hrSchemas";

function createContext(user: TrpcContext["user"]): TrpcContext {
  return { user, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("Dayflow Team Pulse contracts", () => {
  it("blocks unauthenticated callers from the team conversation and profile photo endpoint", async () => {
    const caller = appRouter.createCaller(createContext(null));
    await expect(caller.hr.teamMessages()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.hr.uploadProfilePhoto({ dataUrl: "data:image/png;base64,AA==", mimeType: "image/png" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("accepts bounded team messages and rejects blank message bodies", () => {
    expect(teamMessageInput.parse({ body: "Hello team 👋" }).body).toBe("Hello team 👋");
    expect(() => teamMessageInput.parse({ body: "   " })).toThrow();
  });

  it("limits reactions and profile photo formats to safe structured inputs", () => {
    expect(messageReactionInput.parse({ messageId: 5, emoji: "🎉" })).toMatchObject({ messageId: 5, emoji: "🎉" });
    expect(profilePhotoInput.parse({ dataUrl: "data:image/webp;base64,AA==", mimeType: "image/webp" }).mimeType).toBe("image/webp");
    expect(() => profilePhotoInput.parse({ dataUrl: "data:image/gif;base64,AA==", mimeType: "image/gif" as "image/png" })).toThrow();
  });
});
