import type { Server as HttpServer } from "http";
import type { Request } from "express";
import { Server } from "socket.io";
import { sdk } from "./_core/sdk";

let io: Server | null = null;

export function registerRealtime(server: HttpServer) {
  io = new Server(server, { path: "/api/realtime", cors: { origin: true, credentials: true } });
  io.use(async (socket, next) => {
    try {
      const user = await sdk.authenticateRequest(socket.request as Request);
      socket.data.userId = user.id;
      next();
    } catch {
      next(new Error("Authentication required"));
    }
  });
  io.on("connection", socket => {
    socket.join("team-pulse");
  });
}

export function emitTeamRefresh() {
  io?.to("team-pulse").emit("team:refresh");
}
