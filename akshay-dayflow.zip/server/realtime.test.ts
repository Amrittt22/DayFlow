import { createServer } from "http";
import type { AddressInfo } from "net";
import { afterEach, describe, expect, it, vi } from "vitest";
import { io as createClient, type Socket } from "socket.io-client";

vi.mock("./_core/sdk", () => ({
  sdk: {
    authenticateRequest: vi.fn().mockResolvedValue({ id: 42 }),
  },
}));

import { emitTeamRefresh, registerRealtime } from "./realtime";

describe("Dayflow Team Pulse real-time delivery", () => {
  const servers: ReturnType<typeof createServer>[] = [];
  const clients: Socket[] = [];

  afterEach(async () => {
    clients.splice(0).forEach(client => client.disconnect());
    await Promise.all(servers.splice(0).map(server => new Promise<void>(resolve => server.close(() => resolve()))));
  });

  it("delivers a protected team refresh event to a connected browser client", async () => {
    const server = createServer();
    servers.push(server);
    registerRealtime(server);
    await new Promise<void>(resolve => server.listen(0, "127.0.0.1", () => resolve()));
    const { port } = server.address() as AddressInfo;
    const client = createClient(`http://127.0.0.1:${port}`, { path: "/api/realtime", transports: ["websocket"] });
    clients.push(client);
    await new Promise<void>((resolve, reject) => {
      client.once("connect", () => resolve());
      client.once("connect_error", reject);
    });
    const received = new Promise<void>(resolve => client.once("team:refresh", () => resolve()));
    emitTeamRefresh();
    await expect(received).resolves.toBeUndefined();
    expect(client.connected).toBe(true);
  });
});
