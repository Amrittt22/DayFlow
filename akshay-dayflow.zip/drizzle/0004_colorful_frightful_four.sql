CREATE TABLE `action_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assigneeUserId` int NOT NULL,
	`createdByUserId` int NOT NULL,
	`title` varchar(160) NOT NULL,
	`detail` text,
	`priority` enum('normal','high') NOT NULL DEFAULT 'normal',
	`status` enum('open','completed') NOT NULL DEFAULT 'open',
	`dueAt` bigint,
	`completedAt` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `action_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `action_items` ADD CONSTRAINT `action_items_assigneeUserId_users_id_fk` FOREIGN KEY (`assigneeUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `action_items` ADD CONSTRAINT `action_items_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `action_items_assignee_status_idx` ON `action_items` (`assigneeUserId`,`status`);--> statement-breakpoint
CREATE INDEX `action_items_created_by_idx` ON `action_items` (`createdByUserId`);--> statement-breakpoint
CREATE INDEX `action_items_due_idx` ON `action_items` (`dueAt`);