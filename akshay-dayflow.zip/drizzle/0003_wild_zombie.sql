CREATE TABLE `message_reactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`messageId` int NOT NULL,
	`userId` int NOT NULL,
	`emoji` varchar(16) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `message_reactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `message_reactions_unique` UNIQUE(`messageId`,`userId`,`emoji`)
);
--> statement-breakpoint
CREATE TABLE `team_channels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(48) NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` varchar(240),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `team_channels_id` PRIMARY KEY(`id`),
	CONSTRAINT `team_channels_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `team_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`channelId` int NOT NULL,
	`senderUserId` int NOT NULL,
	`body` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `team_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `employee_profiles` ADD `avatarUrl` varchar(1024);--> statement-breakpoint
ALTER TABLE `message_reactions` ADD CONSTRAINT `message_reactions_messageId_team_messages_id_fk` FOREIGN KEY (`messageId`) REFERENCES `team_messages`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `message_reactions` ADD CONSTRAINT `message_reactions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `team_messages` ADD CONSTRAINT `team_messages_channelId_team_channels_id_fk` FOREIGN KEY (`channelId`) REFERENCES `team_channels`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `team_messages` ADD CONSTRAINT `team_messages_senderUserId_users_id_fk` FOREIGN KEY (`senderUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `message_reactions_message_idx` ON `message_reactions` (`messageId`);--> statement-breakpoint
CREATE INDEX `team_messages_channel_created_idx` ON `team_messages` (`channelId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `team_messages_sender_idx` ON `team_messages` (`senderUserId`);